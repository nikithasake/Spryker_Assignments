<?php

namespace Pyz\Glue\ProductListingPage\Controller;

use Generated\Shared\Transfer\ProductAbstractTransfer;
use Generated\Shared\Transfer\ProductConcreteTransfer;
use Spryker\Glue\Kernel\Controller\AbstractController;
use Spryker\Glue\Kernel\PermissionAwareTrait;
use Symfony\Component\HttpFoundation\Request;

class ProductListingPageResourceController extends AbstractController
{
    use PermissionAwareTrait;

    /**
     * @var array
     */
    protected static $sampleProducts = [
        [
            'sku' => 'SKU123',
            'name' => 'Product',
            'description' => 'This is product 1',
            'category' => 'Category A',
            'price' => 100.00,
            'quantity' => 10,
        ],
        // Add more sample products here
    ];

    /**
     * @param \Symfony\Component\HttpFoundation\Request $request
     * @param int $categoryId
     *
     * @return \Generated\Shared\Transfer\ProductConcreteTransfer[]
     */
    public function getProductListingPageAction(Request $request, int $categoryId): array
    {
        // Retrieve all products for the given category
        $products = $this->getProductsByCategoryId($categoryId);

        return $products;
    }

    /**
     * @param \Symfony\Component\HttpFoundation\Request $request
     * @param int $categoryId
     *
     * @return \Generated\Shared\Transfer\ProductConcreteTransfer[]
     */
    public function searchProductListingPageAction(Request $request, int $categoryId): array
    {
        // Get the search query parameter from the request
        $searchQuery = $request->query->get('q');

        // Filter products based on the search query
        $filteredProducts = $this->filterProductsBySearchQuery($categoryId, $searchQuery);

        return $filteredProducts;
    }

    /**
     * @param \Symfony\Component\HttpFoundation\Request $request
     * @param int $categoryId
     *
     * @return \Generated\Shared\Transfer\ProductConcreteTransfer[]
     */
    public function filterProductListingPageAction(Request $request, int $categoryId): array
    {
        // Get the filter parameters from the request
        $subCategory = $request->query->get('sub_category');
        $priceRange = $request->query->get('price_range');
        $availability = $request->query->get('availability');

        // Filter products based on the provided criteria
        $filteredProducts = $this->filterProducts($categoryId, $subCategory, $priceRange, $availability);

        return $filteredProducts;
    }

    /**
     * @param int $categoryId
     *
     * @return \Generated\Shared\Transfer\ProductConcreteTransfer[]
     */
    protected function getProductsByCategoryId(int $categoryId): array
    {
        // Mock implementation: Retrieve products from the static sample data
        return array_filter(static::$sampleProducts, function ($product) use ($categoryId) {
            return $product['category'] === 'Category ' . $categoryId;
        });
    }

    /**
     * @param int $categoryId
     * @param string|null $searchQuery
     *
     * @return \Generated\Shared\Transfer\ProductConcreteTransfer[]
     */
    protected function filterProductsBySearchQuery(int $categoryId, ?string $searchQuery): array
    {
        // Mock implementation: Filter products based on the search query
        $filteredProducts = $this->getProductsByCategoryId($categoryId);

        if ($searchQuery) {
            $searchQuery = strtolower($searchQuery);
            $filteredProducts = array_filter($filteredProducts, function ($product) use ($searchQuery) {
                $productName = strtolower($product['name']);
                return strpos($productName, $searchQuery) !== false;
            });
        }

        return $filteredProducts;
    }

    /**
     * @param int $categoryId
     * @param string|null $subCategory
     * @param array|null $priceRange
     * @param bool|null $availability
     *
     * @return \Generated\Shared\Transfer\ProductConcreteTransfer[]
     */
    protected function filterProducts(
        int $categoryId,
        ?string $subCategory,
        ?array $priceRange,
        ?bool $availability
    ): array {
        // Mock implementation: Filter products based on the provided criteria
        $filteredProducts = $this->getProductsByCategoryId($categoryId);

        if ($subCategory) {
            $filteredProducts = array_filter($filteredProducts, function ($product) use ($subCategory) {
                return $product['sub_category'] === $subCategory;
            });
        }

        if ($priceRange && count($priceRange) === 2) {
            $minPrice = $priceRange[0];
            $maxPrice = $priceRange[1];

            $filteredProducts = array_filter($filteredProducts, function ($product) use ($minPrice, $maxPrice) {
                return $product['price'] >= $minPrice && $product['price'] <= $maxPrice;
            });
        }

        if ($availability !== null) {
            $filteredProducts = array_filter($filteredProducts, function ($product) use ($availability) {
                return $product['quantity'] > 0 === $availability;
            });
        }

        return $filteredProducts;
    }
}
