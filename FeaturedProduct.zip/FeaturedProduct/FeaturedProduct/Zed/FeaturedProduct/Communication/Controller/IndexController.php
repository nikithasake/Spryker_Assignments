<?php

namespace Pyz\Zed\FeaturedProduct\Communication\Controller;

use Generated\Shared\Transfer\ProductAbstractTransfer;
use Generated\Shared\Transfer\TrendProductListTransfer;
use Spryker\Zed\Kernel\Communication\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;

/**
 * @method \Pyz\Zed\FeaturedProduct\Business\FeaturedProductFacadeInterface getFacade()
 */
class IndexController extends AbstractController
{
    /**
     * @return array
     */
    public function indexAction()
    {

        $trendProductListTransfer = new TrendProductListTransfer();
     
        //$trendProductListTransfer->setAttributes(['featuredproducts' => 'Yes']);
        
        $productAbstractData= $this->getFacade()->findAttribute($trendProductListTransfer);
        //dd($productAbstractData);
        
        return ['featuredproducts' => $productAbstractData];  
    }
}
