<?php

namespace Pyz\Yves\HomePage\Plugin;

use Generated\Shared\Transfer\TrendProductListTransfer;
use Pyz\Client\FeaturedProduct\FeaturedProductClientInterface;

class TrendProductPlugin {

    protected $featuredProductClientInterface;
    public function __construct(FeaturedProductClientInterface $featuredProductClientInterface){
            $this->featuredProductClientInterface = $featuredProductClientInterface;
    }

    public function getClient(TrendProductListTransfer $trendProductListTransfer) : TrendProductListTransfer{
       return  $this->featuredProductClientInterface->findAttribute($trendProductListTransfer);
    }
}