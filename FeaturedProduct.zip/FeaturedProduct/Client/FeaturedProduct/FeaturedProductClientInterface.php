<?php


namespace Pyz\Client\FeaturedProduct;

use Generated\Shared\Transfer\TrendProductListTransfer;
use Generated\Shared\Transfer\TrendProductTransfer;

interface FeaturedProductClientInterface
{
    /**
     * @param \Generated\Shared\Transfer\TrendProductListTransfer $TrendProductListTransfer
     *
     *
     */
    public function findAttribute(TrendProductListTransfer $TrendProductListTransfer): TrendProductListTransfer;
}
