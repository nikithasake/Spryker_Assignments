<?php
// FeaturedProductFactory.php

namespace Pyz\Client\FeaturedProduct;

use Pyz\Client\FeaturedProduct\Zed\FeaturedProductZedStubInterface;
use Pyz\Client\FeaturedProduct\Zed\FeaturedProductZedStub;
use Spryker\Client\Kernel\AbstractFactory;
use Spryker\Client\ZedRequest\ZedRequestClientInterface;

class FeaturedProductFactory extends AbstractFactory
{
    /**
     * @return \Pyz\Client\FeaturedProduct\Zed\FeaturedProducZedStubInterface
     */
    public function createFeaturedProductZedStub(): FeaturedProductZedStubInterface
    {
        return new FeaturedProductZedStub($this->getZedRequestClient());
    }
    protected function getZedRequestClient(): ZedRequestClientInterface
    {
       
        return $this->getProvidedDependency(FeaturedProductDependencyProvider::CLIENT_ZED_REQUEST);
    }
}
