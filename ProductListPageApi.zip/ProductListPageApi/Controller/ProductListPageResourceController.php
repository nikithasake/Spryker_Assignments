<?php

namespace Pyz\Glue\ProductListPage\Controller;

use Generated\Shared\Transfer\RestProductListsResponseAttributesTransfer;
use Spryker\Glue\GlueApplication\Controller\AbstractGlueController;

class ProductListPageResourceController extends AbstractGlueController
{
    /**
     *
     * @param string $category_id
     *
     * @return \Generated\Shared\Transfer\RestProductListsResponseAttributesTransfer
     */
    public function getResourceByIdAction(string $category_id): RestProductListsResponseAttributesTransfer
    {
        $products = $this->getFactory()->createMockProductAPI()->getProductsByCategory($category_id);

        $responseAttributesTransfer = new RestProductListsResponseAttributesTransfer();
        $responseAttributesTransfer->setProducts($products);

        return $responseAttributesTransfer;
    }

    /**
     *
     * @param string $category_id
     * @param string $search
     *
     * @return \Generated\Shared\Transfer\RestProductListsResponseAttributesTransfer
     */
    public function searchAction(string $category_id, string $search): RestProductListsResponseAttributesTransfer
    {
        $products = $this->getFactory()->createMockProductAPI()->searchProductsByCategory($category_id, $search);

        $responseAttributesTransfer = new RestProductListsResponseAttributesTransfer();
        $responseAttributesTransfer->setProducts($products);

        return $responseAttributesTransfer;
    }

    /**
     *
     * @param string $category_id
     * @param array|null $queryParameters
     *
     * @return \Generated\Shared\Transfer\RestProductListsResponseAttributesTransfer
     */
    public function filterAction(string $category_id, ?array $queryParameters = null): RestProductListsResponseAttributesTransfer
    {
        $products = $this->getFactory()->createMockProductAPI()->filterProductsByCategory($category_id, $queryParameters);

        $responseAttributesTransfer = new RestProductListsResponseAttributesTransfer();
        $responseAttributesTransfer->setProducts($products);

        return $responseAttributesTransfer;
    }
}
