<?php

// src/Pyz/Glue/ProductListPage/ProductListPageFactory.php

namespace Pyz\Glue\ProductListPage;

use Spryker\Glue\Kernel\AbstractFactory;

class ProductListPageFactory extends AbstractFactory
{
    /**
     * @return \Pyz\Glue\ProductListPage\MockProductAPI
     */
    public function createMockProductAPI(): MockProductAPI
    {
        return new MockProductAPI();
    }
}
