<?php

namespace Pyz\Zed\FeaturedProduct\Business;


use Pyz\Zed\FeaturedProduct\Business\Reader\AttributeReader;
use Pyz\Zed\FeaturedProduct\Business\Reader\AttributeReaderInterface;
use Pyz\Zed\FeaturedProduct\FeaturedProductDependencyProvider;
use Pyz\Zed\FeaturedProduct\Persistence\FeaturedProductRepository;
use Pyz\Zed\FeaturedProduct\Persistence\FeaturedProductRepositoryInterface;
use Spryker\Zed\Kernel\Business\AbstractBusinessFactory;
use Spryker\Zed\PriceProduct\Business\PriceProductFacadeInterface;
use Spryker\Zed\ProductImage\Business\ProductImageFacadeInterface;

/**
 * @method \Pyz\Zed\FeaturedProduct\Persistence\FeaturedProductEntityManagerInterface getEntityManager()
 * @method \Pyz\Zed\FeaturedProduct\Persistence\FeaturedProductRepositoryInterface getRepository()
 */
class FeaturedProductBusinessFactory extends AbstractBusinessFactory
{
   
    public function createAttributeReader(): AttributeReaderInterface
    {
        // print_r("I am createStringreader in BusinessFactory");
        return new AttributeReader($this->getPriceProductFacade(),
        $this->getProductImageFacade(),
    );
    }

    public function getPriceProductFacade(): PriceProductFacadeInterface
    {
        return $this->getProvidedDependency(FeaturedProductDependencyProvider::FACADE_PRICE_PRODUCT);
    }
     
    public function getProductImageFacade(): ProductImageFacadeInterface
    {
        return $this->getProvidedDependency(FeaturedProductDependencyProvider::FACADE_IMAGE_PRODUCT);
    }
    
    


}
