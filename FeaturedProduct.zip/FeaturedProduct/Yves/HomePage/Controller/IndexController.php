<?php

namespace Pyz\Yves\HomePage\Controller;

use Generated\Shared\Transfer\ProductAbstractTransfer;
use Generated\Shared\Transfer\TrendProductListTransfer;
use Pyz\Client\FeaturedProduct\FeaturedProductClient;
use Spryker\Yves\Kernel\Controller\AbstractController;
use Pyz\Yves\HomePage\Plugin\TrendProductPlugin;
use Symfony\Component\HttpFoundation\Request;
use SprykerShop\Yves\HomePage\Controller\IndexController as NewController;

/**
 * @method \Pyz\Client\FeaturedProduct\FeaturedProductClientInterface getClient()
 */
class IndexController extends NewController
{
    /**
     *
     *
     * @return \Spryker\Yves\Kernel\View\View
     */
    public function indexAction()
    {
        $featuredProductClient = new FeaturedProductClient();
        $trendProductListTransfer = new TrendProductListTransfer();
        $trendProductPlugin = new TrendProductPlugin($featuredProductClient);
       $products = $trendProductPlugin->getClient($trendProductListTransfer);
       $featuredProducts = $products->getProducts();
    
        $result = [];
       foreach($featuredProducts as $product){
        $sku = $product->getSku();
        $name = $product->getName();
        $image=$product->getImage();
        $price=$product->getPrice();

         $result[] = [
                'sku' => $sku,
                'name' => $name,
                'price' => $price,
                'image' => $image,
            ];
       }
    // print_r($result);die;
    
        $data = ['products' => $result];
        return $this->view(
            $data,
            [],
            '@HomePage/views/home/home.twig'
        );
    }
}
