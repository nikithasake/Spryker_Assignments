<?php

namespace Pyz\Glue\ProductListingPage\Plugin;

use Generated\Shared\Transfer\RestProductListsRequestAttributesTransfer;
use Spryker\Glue\GlueApplicationExtension\Dependency\Plugin\ResourceRouteCollectionInterface;
use Spryker\Glue\Kernel\AbstractPlugin;

class ProductListingPageRoutePlugin extends AbstractPlugin
{
    /**
     * @param \Spryker\Glue\GlueApplicationExtension\Dependency\Plugin\ResourceRouteCollectionInterface $resourceRouteCollection
     *
     * @return \Spryker\Glue\GlueApplicationExtension\Dependency\Plugin\ResourceRouteCollectionInterface
     */
    public function configure(ResourceRouteCollectionInterface $resourceRouteCollection): ResourceRouteCollectionInterface
    {
        $this->addProductListingPageRoute($resourceRouteCollection);

        return $resourceRouteCollection;
    }

    /**
     * @param \Spryker\Glue\GlueApplicationExtension\Dependency\Plugin\ResourceRouteCollectionInterface $resourceRouteCollection
     *
     * @return \Spryker\Glue\GlueApplicationExtension\Dependency\Plugin\ResourceRouteCollectionInterface
     */
    protected function addProductListingPageRoute(ResourceRouteCollectionInterface $resourceRouteCollection): ResourceRouteCollectionInterface
    {
        $resourceRouteCollection
            ->addGet('get', '/product-listing-page/{category_name}', [
                'ProductListingPageApi',
                'GetProductListingPage',
            ])
            ->addGet('get', '/product-listing-page/{category_id}/search', [
                'ProductListingPageApi',
                'SearchProductListingPage',
            ])
            ->addGet('get', '/product-listing-page/{category_id}/filter', [
                'ProductListingPageApi',
                'FilterProductListingPage',
            ]);

        return $resourceRouteCollection;
    }
}
