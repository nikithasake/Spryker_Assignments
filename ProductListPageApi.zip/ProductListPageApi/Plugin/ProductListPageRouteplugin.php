<?php

namespace Pyz\Glue\ProductListPage\Plugin;

use Spryker\Glue\Kernel\AbstractPlugin;
use Spryker\Glue\ProductListsRestApi\Plugin\ProductListsRoutePlugin;
use Spryker\Glue\Router\Route\RouteCollection;
use Spryker\Glue\Router\Route\RouteCollectionInterface;

class ProductListPageRoutePlugin extends AbstractPlugin
{
    /**
     * @param \Spryker\Glue\Router\Route\RouteCollectionInterface $routeCollection
     *
     * @return \Spryker\Glue\Router\Route\RouteCollectionInterface
     */
    public function extend(RouteCollectionInterface $routeCollection): RouteCollectionInterface
    {
        $this->addProductListPageRoute($routeCollection);

        return $routeCollection;
    }

    /**
     * @param \Spryker\Glue\Router\Route\RouteCollectionInterface $routeCollection
     *
     * @return void
     */
    protected function addProductListPageRoute(RouteCollectionInterface $routeCollection): void
    {
        $route = $this->buildRoute('/product-list-page/{category_id}', 'ProductListPage', 'ProductListPageResource', 'getResourceById');
        $routeCollection->add($route);

        $route = $this->buildRoute('/product-list-page/{category_id}/search', 'ProductListPage', 'ProductListPageResource', 'search');
        $routeCollection->add($route);

        $route = $this->buildRoute('/product-list-page/{category_id}/filter', 'ProductListPage', 'ProductListPageResource', 'filter');
        $routeCollection->add($route);
    }

    /**
     * @param string $path
     * @param string $module
     * @param string $controller
     * @param string $action
     *
     * @return \Spryker\Glue\Router\Route\Route
     */
    protected function buildRoute(string $path, string $module, string $controller, string $action)
    {
        return RouteCollection::create()
            ->get($path, $module, $controller, $action)
            ->addDefaults([
                ProductListsRoutePlugin::CONTROLLER_RESOURCE_TYPE => 'product-lists',
            ]);
    }
}
