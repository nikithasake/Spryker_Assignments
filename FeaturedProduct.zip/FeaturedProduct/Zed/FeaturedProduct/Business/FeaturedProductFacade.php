<?php

namespace Pyz\Zed\FeaturedProduct\Business;

use Generated\Shared\Transfer\TrendProductListTransfer;
use Pyz\Zed\FeaturedProduct\Business\FeaturedProductFacadeInterface;
use Pyz\Zed\FeaturedProduct\Persistence\FeaturedProductRepositoryInterface;
use Spryker\Zed\Kernel\Business\AbstractFacade;

/**
 * @method \Pyz\Zed\\Business\FeaturedProduct\FeaturedProductBusinessFactory getFactory()
 * @method \Pyz\Zed\FeaturedProduct\Persistence\FeaturedProductEntityManagerInterface getEntityManager()
 * @method \Pyz\Zed\FeaturedProduct\Persistence\FeaturedProductRepositoryInterface getRepository()
 */
class FeaturedProductFacade extends AbstractFacade implements FeaturedProductFacadeInterface
{
   
    public function findAttribute(TrendProductListTransfer $TrendProductListTransfer): TrendProductListTransfer
    {
        // print_r("findFeaturedProduct");
        // $this->getFactory()->createFeaturedProductRepository();
        return $this->getFactory()
            ->createAttributeReader()
            ->findAttributeString($TrendProductListTransfer);
    }
   
    
}
