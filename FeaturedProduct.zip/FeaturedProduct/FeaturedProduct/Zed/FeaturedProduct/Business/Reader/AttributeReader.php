<?php

namespace Pyz\Zed\FeaturedProduct\Business\Reader;

use Generated\Client\Ide\PriceProduct;
use Pyz\Zed\FeaturedProduct\Persistence\FeaturedProductRepository;
use Pyz\Zed\FeaturedProduct\Persistence\FeaturedProductRepositoryInterface;
use Generated\Shared\Transfer\ProductAbstractTransfer;
use Generated\Shared\Transfer\TrendProductListTransfer;
use Spryker\Zed\PriceProduct\Business\PriceProductFacadeInterface;
use Spryker\Zed\ProductImage\Business\ProductImageFacadeInterface;

class AttributeReader implements AttributeReaderInterface
{
    /**
     * @var FeaturedProductRepositoryInterface
     */
    protected $featuredProductRepository;

    /**
     * @var PriceProductFacadeInterface
     */
    protected $priceProductFacade;

       /**
     * @var ProductImageFacadeInterface
     */
    protected $ProductImageFacade;



    /**
     * AttributeReader constructor.
     *
     * @param FeaturedProductRepositoryInterface $featuredProductRepository
     *
     */
    public function __construct(
        // FeaturedProductRepositoryInterface $featuredProductRepository,
        PriceProductFacadeInterface $pricefacade,
        ProductImageFacadeInterface $imagefacade
     
    ) {
        // $this->featuredProductRepository = $featuredProductRepository;
        $this->priceProductFacade = $pricefacade;
        $this->ProductImageFacade = $imagefacade;
      
    }

    /**
     * Finds FeaturedProduct by ID.
     *
     * @param ProductAbstractTransfer $productAbstractTransfer
     *
     * @return ProductAbstractTransfer
     */
    public function findAttribute(ProductAbstractTransfer $TrendProductListTransfer): TrendProductListTransfer
    {
        
        $TrendProductListTransfer = $this->featuredProductRepository->findPyzProductByAttribute($TrendProductListTransfer->getAttributes());

        if (!$TrendProductListTransfer) {
            return new TrendProductListTransfer();
        }

        return $TrendProductListTransfer;
    }

    public function createFeaturedProductRepository(): FeaturedProductRepositoryInterface
    {

        return new FeaturedProductRepository(

            $this->priceProductFacade,
            $this->ProductImageFacade

        );

    }

    /**
     * Finds FeaturedProduct by reversed string.
     *
     * @param TrendProductListTransfer $TrendProductListTransfer
     *
     * @return TrendProductListTransfer
     */
    public function findAttributeString(TrendProductListTransfer $TrendProductListTransfer): TrendProductListTransfer
    {
        $this->featuredProductRepository = $this->createFeaturedProductRepository();
        $TrendProductListTransfer = $this->featuredProductRepository->findPyzProductByAttribute();
         
        return $TrendProductListTransfer;
    }
}
