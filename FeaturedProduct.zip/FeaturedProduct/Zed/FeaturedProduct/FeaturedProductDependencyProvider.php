<?php

namespace Pyz\Zed\FeaturedProduct;

use Spryker\Zed\Kernel\AbstractBundleDependencyProvider;
use Spryker\Zed\Kernel\Container;
use Spryker\Zed\PriceProduct\Business\PriceProductFacadeInterface;

class FeaturedProductDependencyProvider extends AbstractBundleDependencyProvider
{
    public const FACADE_PRICE_PRODUCT = 'FACADE_PRICE_PRODUCT';
    public const FACADE_IMAGE_PRODUCT = 'FACADE_IMAGE_PRODUCT';

    public const FACADE_FEATURED_PRODUCT = 'FACADE_FEATURED_PRODUCT';


    /**
     * @param Container $container
     *
     * @return Container
     */
    public function provideBusinessLayerDependencies(Container $container)
    {
        $container = parent::provideBusinessLayerDependencies($container);
        $container = $this->addPriceProductFacade($container);
        $container=$this->addProductImageFacade($container);

        return $container;
    }

    /**
     * @param Container $container
     *
     * @return Container
     */
    protected function addPriceProductFacade(Container $container): Container
    {
        $container->set(static::FACADE_PRICE_PRODUCT, function (Container $container) {
            return $container->getLocator()->priceProduct()->facade();
        });

        return $container;
    }

    protected function addProductImageFacade(Container $container): Container
    {
        $container->set(static::FACADE_IMAGE_PRODUCT, function (Container $container) {
            return $container->getLocator()->productImage()->facade();
        });

        return $container;
    }

    
    protected function addGatewayController(Container $container): Container
    {
        $container->set(static::FACADE_FEATURED_PRODUCT, function (Container $container) {
            return $container->getLocator()->featuredProduct()->facade();
        });

        return $container;
    }

    /**
     * @param \Spryker\Zed\Kernel\Container $container
     *
     * @return \Spryker\Zed\Kernel\Container
     */
    public function provideCommunicationLayerDependencies(Container $container): Container
    {
        $container = parent::provideCommunicationLayerDependencies($container);
        $container = $this->addGatewayController($container);

        return $container;
    }
}
