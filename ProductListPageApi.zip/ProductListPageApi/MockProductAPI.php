<?php

namespace Pyz\Glue\ProductListPage;

class MockProductAPI
{
    private $products;

    public function __construct()
    {
        // Sample product data for testing
        $this->products = [
            [
                'sku' => '127',
                'name' => 'Asus',
                'description' => 'This is a unique product bundle featuring various Asus products.',
                'category' => 'Category A',
                'price' => 10.99,
                'quantity' => 100,
            ],
            [
                'sku' => '450',
                'name' => 'Lenova',
                'description' => 'an incredible engineering achievement made possible by reducing the bezel ',
                'category' => 'Category B',
                'price' => 20.49,
                'quantity' => 50,
            ],
            // Add more sample products here
        ];
    }

    public function getProductsByCategory(string $category_id): array
    {
        $productsInCategory = [];
        foreach ($this->products as $product) {
            if ($product['category'] === $category_id) {
                $productsInCategory[] = $product;
            }
        }
        return $productsInCategory;
    }

    public function searchProductsByCategory(string $category_id, string $searchTerm): array
    {
        $searchResults = [];
        foreach ($this->products as $product) {
            if ($product['category'] === $category_id && stripos($product['name'], $searchTerm) !== false) {
                $searchResults[] = $product;
            }
        }
        return $searchResults;
    }

    public function filterProductsByCategory(string $category_id, ?array $filters = null): array
    {
        $filteredProducts = [];
        foreach ($this->products as $product) {
            if ($product['category'] === $category_id) {
                $passFilters = true;
                if ($filters) {
                    foreach ($filters as $filterKey => $filterValue) {
                        if (isset($product[$filterKey]) && $product[$filterKey] !== $filterValue) {
                            $passFilters = false;
                            break;
                        }
                    }
                }
                if ($passFilters) {
                    $filteredProducts[] = $product;
                }
            }
        }
        return $filteredProducts;
    }
}
