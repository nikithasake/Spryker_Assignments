<?php

namespace Pyz\Zed\FeaturedProduct\Business;

use Generated\Shared\Transfer\ProductAbstractTransfer;
use Generated\Shared\Transfer\TrendProductListTransfer;

interface FeaturedProductFacadeInterface
{
    
    // public function reverseString(FeaturedProductTransfer $FeaturedProductTransfer): FeaturedProductTransfer;

    /**
     * Creates a FeaturedProduct entity.
     *
     * @api
     * @param \Generated\Shared\Transfer\FeaturedProductTransfer $FeaturedProductTransfer
     * @return \Generated\Shared\Transfer\FeaturedProductTransfer
     */
    //  public function createFeaturedProductEntity(FeaturedProductTransfer $FeaturedProductTransfer): FeaturedProductTransfer;

    /**
     * Finds a FeaturedProduct entity.
     *
     * @api
     * @param \Generated\Shared\Transfer\TrendProductListTransfer $TrendProductListTransfer
     * @return TrendProductListTransfer;
     */
    public function findAttribute(TrendProductListTransfer $TrendProductListTransfer): TrendProductListTransfer;
}
