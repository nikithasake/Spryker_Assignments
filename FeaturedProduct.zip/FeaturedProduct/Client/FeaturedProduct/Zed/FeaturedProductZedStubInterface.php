<?php

// FeaturedProductStubInterface.php

namespace Pyz\Client\FeaturedProduct\Zed;

use Generated\Shared\Transfer\TrendProductListTransfer;

interface FeaturedProductZedStubInterface
{
    /**
     * @param \Generated\Shared\Transfer\TrendProductListTransfer $TrendProductListTransfer
     *
     */
    public function findAttribute(TrendProductListTransfer $TrendProductListTransfer): TrendProductListTransfer;
}
