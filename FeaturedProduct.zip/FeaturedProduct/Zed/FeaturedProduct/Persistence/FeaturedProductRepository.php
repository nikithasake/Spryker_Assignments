<?php

namespace Pyz\Zed\FeaturedProduct\Persistence;

use Generated\Shared\Transfer\ProductImageTransfer;
use Generated\Shared\Transfer\TrendProductListTransfer;
use Generated\Shared\Transfer\TrendProductTransfer;
use Pyz\Zed\FeaturedProduct\Persistence\FeaturedProductRepositoryInterface;
use Spryker\Zed\Kernel\Persistence\AbstractRepository;
use Spryker\Zed\PriceProduct\Business\PriceProductFacadeInterface;
use Spryker\Zed\ProductImage\Business\ProductImageFacadeInterface;

/**
 * @method \Pyz\Zed\FeaturedProduct\Persistence\FeaturedProductPersistenceFactory getFactory()
 */
class FeaturedProductRepository extends AbstractRepository implements FeaturedProductRepositoryInterface
{
    /**
     * @var \Spryker\Zed\PriceProduct\Business\PriceProductFacadeInterface
     */
    protected $priceProductFacade;

    /**
     * @var \Spryker\Zed\ProductImage\Business\ProductImageFacadeInterface
     */
    protected $productImageFacade;

    /**
     * @param \Spryker\Zed\PriceProduct\Business\PriceProductFacadeInterface $priceProductFacade
     * @param \Spryker\Zed\ProductImage\Business\ProductImageFacadeInterface $productImageFacade
     */
    public function __construct(PriceProductFacadeInterface $priceProductFacade, ProductImageFacadeInterface $productImageFacade)
    {
        $this->priceProductFacade = $priceProductFacade;
        $this->productImageFacade = $productImageFacade;
    }

    public function findPyzProductByAttribute(): TrendProductListTransfer
    {
        $featuredProductEntities = $this->getFactory()
            ->createProductAbstractLocalizedQuery()
            ->where('JSON_EXTRACT(attributes, \'$.featuredproducts\') = ?', 'Yes', \PDO::PARAM_STR)
            ->find();

        $result = [];
        $trendProductListTransfer = new TrendProductListTransfer();
        foreach ($featuredProductEntities as $featuredProductEntity) {
            $sku = $featuredProductEntity->getSpyProductAbstract()->getSku();
            $name = $featuredProductEntity->getName();
            $price = $this->getProductPrice($featuredProductEntity->getSpyProductAbstract()->getIdProductAbstract(), 'DE_DE');
            $image = $this->getProductImage($featuredProductEntity->getSpyProductAbstract()->getIdProductAbstract());

            $trendProductTransfer = new TrendProductTransfer();
            $trendProductTransfer->setSku($sku);
            $trendProductTransfer->setName($name);
            $trendProductTransfer->setImage($image);
            $trendProductTransfer->setPrice($price);

            $trendProductListTransfer->addProducts($trendProductTransfer);
        }
        // dd($trendProductListTransfer);
        return $trendProductListTransfer;
    }

    /**
     * Get the price information for a product abstract in the given currency.
     *
     * @param int $idProductAbstract
     * @param string $currencyCode
     * @return int|null
     */
    public function getProductPrice(int $idProductAbstract, string $currencyCode): ?int
    {
        $priceData = $this->priceProductFacade->findProductAbstractPrice($idProductAbstract)->getMoneyValue()->getGrossAmount();

        return $priceData;
    }

    public function getProductImage(int $idProductAbstract)
    {
        $imageData = $this->productImageFacade->findProductImageSetById($idProductAbstract)->getProductImages();

        foreach ($imageData as $image){
           $images = $image->getExternalUrlLarge();
         }
        return $images;
    }
}
