<?php

namespace Pyz\Zed\FeaturedProduct\Communication\Controller;

use Generated\Shared\Transfer\ProductAbstractTransfer;
use Generated\Shared\Transfer\TrendProductListTransfer;
use Generated\Shared\Transfer\TrendProductTransfer;
use Spryker\Zed\Kernel\Communication\Controller\AbstractGatewayController;


/**
 * Gateway Controller for FeaturedProduct.
 * @method \pyz\Zed\FeaturedProduct\Business\FeaturedProductFacadeInterface getFacade()
 */
class GatewayController extends AbstractGatewayController
{
    public function findAttributeAction(TrendProductListTransfer $TrendProductListTransfer): TrendProductListTransfer
    {
        return $this->getFacade()
            ->findAttribute($TrendProductListTransfer);
    }
}
