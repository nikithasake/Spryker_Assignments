<?php

// FeaturedProductZedStub.php

namespace Pyz\Client\FeaturedProduct\Zed;

use Generated\Shared\Transfer\TrendProductListTransfer;
use Spryker\Client\ZedRequest\ZedRequestClient;

class FeaturedProductZedStub implements FeaturedProductZedStubInterface
{
    /**
     * @var \Spryker\Client\ZedRequest\ZedRequestClient
     */
    protected $zedRequestClient;

    /**
     * @param \Spryker\Client\ZedRequest\ZedRequestClient $zedRequestClient
     */
    public function __construct(ZedRequestClient $zedRequestClient)
    {
        $this->zedRequestClient = $zedRequestClient;
    }

    /**
     * @param \Generated\Shared\Transfer\TrendProductListTransfer $TrendProductListTransfer
     * 
     */
    public function findAttribute(TrendProductListTransfer $TrendProductListTransfer): TrendProductListTransfer
    {
        $url = '/featured-product/gateway/find-attribute';

        return $this->zedRequestClient->call($url, $TrendProductListTransfer);
    }
}
