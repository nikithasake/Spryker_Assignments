<?php 

namespace Pyz\Zed\FeaturedProduct\Persistence;

use Orm\Zed\Product\Persistence\SpyProductAbstractQuery;
use Orm\Zed\PriceProduct\Persistence\SpyPriceProductQuery;
use Orm\Zed\ProductImage\Persistence\Base\SpyProductImageSetQuery;
use Orm\Zed\ProductImage\Persistence\SpyProductImageQuery;

use Orm\Zed\Product\Persistence\SpyProductAbstractLocalizedAttributesQuery;
use Spryker\Zed\Kernel\Persistence\AbstractPersistenceFactory;

class FeaturedProductPersistenceFactory extends AbstractPersistenceFactory
{
    /**
     * @return \Orm\Zed\product\Persistence\SpyProductAbstractQuery
     * 
     */
    public function createProductQuery():SpyProductAbstractQuery
    {
        
        return SpyProductAbstractQuery::create();
    }


    public function createProductAbstractLocalizedQuery():SpyProductAbstractLocalizedAttributesQuery
    {
        
        return SpyProductAbstractLocalizedAttributesQuery::create();
    }
    /**
     * @return \Orm\Zed\PriceProduct\Persistence\SpyPriceProductQuery
     * 
     */
    public function createProductPriceQuery():SpyPriceProductQuery
    {
        
        return SpyPriceProductQuery::create();
    }
    public function createProductImageSetQuery():SpyProductImageSetQuery
    {
        return SpyProductImageSetQuery::create();
    }
    public function createProductImageQuery():SpyProductImageQuery
    {
        return SpyProductImageQuery::create();
    }
}