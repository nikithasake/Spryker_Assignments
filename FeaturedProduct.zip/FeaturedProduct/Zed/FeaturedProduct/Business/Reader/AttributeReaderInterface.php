<?php

namespace Pyz\Zed\FeaturedProduct\Business\Reader;

use Generated\Shared\Transfer\TrendProductListTransfer;

interface AttributeReaderInterface
{
    /**
     * Finds FeaturedProduct by ID.
     *
     * @param TrendProductListTransfer $FeaturedProductTransfer
     *
     * @return TrendProductListTransfer
     */
    // public function findAttribute(TrendProductListTransfer $FeaturedProductTransfer): TrendProductListTransfer;

    /**
     * Finds FeaturedProduct by reversed string.
     *
     * @param TrendProductListTransfer $TrendProductListTransfer
     *
     * @return TrendProductListTransfer
     */
    public function findAttributeString(TrendProductListTransfer $TrendProductListTransfer): TrendProductListTransfer;
}
