<?php

namespace Pyz\Client\FeaturedProduct;

use Generated\Shared\Transfer\TrendProductListTransfer;
use Pyz\Client\FeaturedProduct\Zed\FeaturedProductZedStubInterface;
use Spryker\Client\Kernel\AbstractClient;

/**
 * @method \Pyz\Client\FeaturedProduct\FeaturedProductFactory getFactory()
 */
class FeaturedProductClient extends AbstractClient implements FeaturedProductClientInterface
{
    /**
     * @var \Pyz\Client\FeaturedProduct\Zed\FeaturedProductZedStubInterface
     */
    /**
     * {@inheritDoc}
     *
     * @param \Generated\Shared\Transfer\TrendProductListTransfer $TrendProductListTransfer
     *
     * 
     */
    public function findAttribute(TrendProductListTransfer $TrendProductListTransfer): TrendProductListTransfer
    {
        return $this->getFactory()->createFeaturedProductZedStub()->findAttribute($TrendProductListTransfer);
    }
}
