<?php

namespace Pyz\Zed\FeaturedProduct\Persistence;

use Generated\Shared\Transfer\TrendProductListTransfer;
use Generated\Shared\Transfer\TrendProductTransfer;

interface FeaturedProductRepositoryInterface
{
    public function findPyzProductByAttribute(): TrendProductListTransfer;

    public function getProductPrice(int $idProductAbstract, string $currencyCode):?int;
}
